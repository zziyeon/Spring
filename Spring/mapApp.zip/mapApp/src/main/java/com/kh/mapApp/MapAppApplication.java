package com.kh.mapApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MapAppApplication.class, args);
	}

}
