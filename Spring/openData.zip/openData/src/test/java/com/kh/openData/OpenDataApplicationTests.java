package com.kh.openData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
